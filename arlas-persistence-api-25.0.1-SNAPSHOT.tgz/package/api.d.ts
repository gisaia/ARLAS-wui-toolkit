/// <reference path="custom.d.ts" />
import { Configuration } from "./configuration";
/**
 *
 * @export
 */
export declare const COLLECTION_FORMATS: {
    csv: string;
    ssv: string;
    tsv: string;
    pipes: string;
};
/**
 *
 * @export
 * @interface FetchAPI
 */
export interface FetchAPI {
    (url: string, init?: any): Promise<Response>;
}
/**
 *
 * @export
 * @interface FetchArgs
 */
export interface FetchArgs {
    url: string;
    options: any;
}
/**
 *
 * @export
 * @class BaseAPI
 */
export declare class BaseAPI {
    protected basePath: string;
    protected fetch: FetchAPI;
    protected configuration: Configuration;
    constructor(configuration?: Configuration, basePath?: string, fetch?: FetchAPI);
}
/**
 *
 * @export
 * @class RequiredError
 * @extends {Error}
 */
export declare class RequiredError extends Error {
    field: string;
    name: "RequiredError";
    constructor(field: string, msg?: string);
}
/**
 *
 * @export
 * @interface DataResource
 */
export interface DataResource {
    /**
     *
     * @type {number}
     * @memberof DataResource
     */
    count?: number;
    /**
     *
     * @type {number}
     * @memberof DataResource
     */
    total?: number;
    /**
     *
     * @type {{ [key: string]: Link; }}
     * @memberof DataResource
     */
    _links?: {
        [key: string]: Link;
    };
    /**
     *
     * @type {Array<DataWithLinks>}
     * @memberof DataResource
     */
    data?: Array<DataWithLinks>;
}
/**
 *
 * @export
 * @interface DataWithLinks
 */
export interface DataWithLinks {
    /**
     *
     * @type {string}
     * @memberof DataWithLinks
     */
    id?: string;
    /**
     *
     * @type {string}
     * @memberof DataWithLinks
     */
    doc_key: string;
    /**
     *
     * @type {string}
     * @memberof DataWithLinks
     */
    doc_zone: string;
    /**
     *
     * @type {Date}
     * @memberof DataWithLinks
     */
    last_update_date: Date;
    /**
     *
     * @type {string}
     * @memberof DataWithLinks
     */
    doc_value: string;
    /**
     *
     * @type {string}
     * @memberof DataWithLinks
     */
    doc_owner: string;
    /**
     *
     * @type {string}
     * @memberof DataWithLinks
     */
    doc_organization: string;
    /**
     *
     * @type {Array<string>}
     * @memberof DataWithLinks
     */
    doc_entities?: Array<string>;
    /**
     *
     * @type {Array<string>}
     * @memberof DataWithLinks
     */
    doc_writers?: Array<string>;
    /**
     *
     * @type {Array<string>}
     * @memberof DataWithLinks
     */
    doc_readers?: Array<string>;
    /**
     *
     * @type {boolean}
     * @memberof DataWithLinks
     */
    _public?: boolean;
    /**
     *
     * @type {{ [key: string]: Link; }}
     * @memberof DataWithLinks
     */
    _links?: {
        [key: string]: Link;
    };
    /**
     *
     * @type {boolean}
     * @memberof DataWithLinks
     */
    updatable?: boolean;
    /**
     *
     * @type {boolean}
     * @memberof DataWithLinks
     */
    ispublic?: boolean;
}
/**
 *
 * @export
 * @interface Exists
 */
export interface Exists {
    /**
     *
     * @type {boolean}
     * @memberof Exists
     */
    exists?: boolean;
}
/**
 *
 * @export
 * @interface Link
 */
export interface Link {
    /**
     *
     * @type {string}
     * @memberof Link
     */
    relation: string;
    /**
     *
     * @type {string}
     * @memberof Link
     */
    href: string;
    /**
     *
     * @type {string}
     * @memberof Link
     */
    type: string;
    /**
     *
     * @type {string}
     * @memberof Link
     */
    method: string;
}
/**
 *
 * @export
 * @interface ModelError
 */
export interface ModelError {
    /**
     *
     * @type {number}
     * @memberof ModelError
     */
    status?: number;
    /**
     *
     * @type {string}
     * @memberof ModelError
     */
    message?: string;
    /**
     *
     * @type {string}
     * @memberof ModelError
     */
    error?: string;
}
/**
 * PersistApi - fetch parameter creator
 * @export
 */
export declare const PersistApiFetchParamCreator: (configuration?: Configuration) => {
    create(body: string, zone: string, key: string, readers?: string[], writers?: string[], pretty?: boolean, options?: any): FetchArgs;
    deleteById(id: string, pretty?: boolean, options?: any): FetchArgs;
    existsById(id: string, pretty?: boolean, options?: any): FetchArgs;
    getById(id: string, pretty?: boolean, options?: any): FetchArgs;
    getGroupsByZone(zone: string, pretty?: boolean, options?: any): FetchArgs;
    list(zone: string, size?: number, page?: number, order?: string, pretty?: boolean, key?: string, options?: any): FetchArgs;
    update(body: string, id: string, last_update: number, key?: string, readers?: string[], writers?: string[], pretty?: boolean, options?: any): FetchArgs;
};
/**
 * PersistApi - functional programming interface
 * @export
 */
export declare const PersistApiFp: (configuration?: Configuration) => {
    create(body: string, zone: string, key: string, readers?: string[], writers?: string[], pretty?: boolean, options?: any): (fetch?: FetchAPI, basePath?: string) => Promise<DataWithLinks>;
    deleteById(id: string, pretty?: boolean, options?: any): (fetch?: FetchAPI, basePath?: string) => Promise<DataWithLinks>;
    existsById(id: string, pretty?: boolean, options?: any): (fetch?: FetchAPI, basePath?: string) => Promise<Exists>;
    getById(id: string, pretty?: boolean, options?: any): (fetch?: FetchAPI, basePath?: string) => Promise<DataWithLinks>;
    getGroupsByZone(zone: string, pretty?: boolean, options?: any): (fetch?: FetchAPI, basePath?: string) => Promise<string>;
    list(zone: string, size?: number, page?: number, order?: string, pretty?: boolean, key?: string, options?: any): (fetch?: FetchAPI, basePath?: string) => Promise<DataResource>;
    update(body: string, id: string, last_update: number, key?: string, readers?: string[], writers?: string[], pretty?: boolean, options?: any): (fetch?: FetchAPI, basePath?: string) => Promise<DataWithLinks>;
};
/**
 * PersistApi - factory interface
 * @export
 */
export declare const PersistApiFactory: (configuration?: Configuration, fetch?: FetchAPI, basePath?: string) => {
    create(body: string, zone: string, key: string, readers?: string[], writers?: string[], pretty?: boolean, options?: any): Promise<DataWithLinks>;
    deleteById(id: string, pretty?: boolean, options?: any): Promise<DataWithLinks>;
    existsById(id: string, pretty?: boolean, options?: any): Promise<Exists>;
    getById(id: string, pretty?: boolean, options?: any): Promise<DataWithLinks>;
    getGroupsByZone(zone: string, pretty?: boolean, options?: any): Promise<string>;
    list(zone: string, size?: number, page?: number, order?: string, pretty?: boolean, key?: string, options?: any): Promise<DataResource>;
    update(body: string, id: string, last_update: number, key?: string, readers?: string[], writers?: string[], pretty?: boolean, options?: any): Promise<DataWithLinks>;
};
/**
 * PersistApi - object-oriented interface
 * @export
 * @class PersistApi
 * @extends {BaseAPI}
 */
export declare class PersistApi extends BaseAPI {
    /**
     * Store a new piece of data for the provided zone and key (auto generate id).
     * @summary Store a new piece of data for the provided zone and key (auto generate id).
     * @param {string} body Value to be persisted.
     * @param {string} zone Zone of the document.
     * @param {string} key The key of the data.
     * @param {Array<string>} [readers] Comma separated values of groups authorized to read the data.
     * @param {Array<string>} [writers] Comma separated values of groups authorized to modify the data.
     * @param {boolean} [pretty] Pretty print
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof PersistApi
     */
    create(body: string, zone: string, key: string, readers?: Array<string>, writers?: Array<string>, pretty?: boolean, options?: any): Promise<DataWithLinks>;
    /**
     * Delete an entry given its key and id.
     * @summary Delete an entry given its key and id.
     * @param {string} id The id of the data.
     * @param {boolean} [pretty] Pretty print
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof PersistApi
     */
    deleteById(id: string, pretty?: boolean, options?: any): Promise<DataWithLinks>;
    /**
     * Check the existence of an entry given its id.
     * @summary Check the existence of an entry given its id.
     * @param {string} id The id of the data.
     * @param {boolean} [pretty] Pretty print
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof PersistApi
     */
    existsById(id: string, pretty?: boolean, options?: any): Promise<Exists>;
    /**
     * Fetch an entry given its id.
     * @summary Fetch an entry given its id.
     * @param {string} id The id of the data.
     * @param {boolean} [pretty] Pretty print
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof PersistApi
     */
    getById(id: string, pretty?: boolean, options?: any): Promise<DataWithLinks>;
    /**
     * Returns the users' groups allowed to interact with the given zone.
     * @summary Returns the users' groups allowed to interact with the given zone.
     * @param {string} zone Zone of the document.
     * @param {boolean} [pretty] Pretty print
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof PersistApi
     */
    getGroupsByZone(zone: string, pretty?: boolean, options?: any): Promise<string>;
    /**
     * Fetch a list of data related to a zone.
     * @summary Fetch a list of data related to a zone.
     * @param {string} zone Zone of the document.
     * @param {number} [size] Page Size
     * @param {number} [page] Page ID
     * @param {string} [order] Date sort order
     * @param {boolean} [pretty] Pretty print
     * @param {string} [key] Filter by key value
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof PersistApi
     */
    list(zone: string, size?: number, page?: number, order?: string, pretty?: boolean, key?: string, options?: any): Promise<DataResource>;
    /**
     * Update an existing value.
     * @summary Update an existing value.
     * @param {string} body Value to be persisted.
     * @param {string} id The id of the data.
     * @param {number} last_update Previous date value of last modification known by client.
     * @param {string} [key] The key of the data.
     * @param {Array<string>} [readers] Comma separated values of groups authorized to read the data.
     * @param {Array<string>} [writers] Comma separated values of groups authorized to modify the data.
     * @param {boolean} [pretty] Pretty print
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof PersistApi
     */
    update(body: string, id: string, last_update: number, key?: string, readers?: Array<string>, writers?: Array<string>, pretty?: boolean, options?: any): Promise<DataWithLinks>;
}
